<?php

    $usuario = "root";
    $password = "";
    $servidor = "localhost";
    $basededatos ="";



$conexion = mysqli_connect  ($servidor,$usuario,"") or die ("No se ha podido conectar con el servidor de Base de datos");


$db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la Base de datos");


        //recuperar las variables
    $descripcionm=$_POST['descripcionm'];
    //sentencia sql
    $sql="INSERT INTO datos VALUES ('$descripcionm')";

    //ejecutamos la centencia de sql
    $ejecutar=mysqli_query($conexion, $sql);
    //verificacion de la ejecucioon
    if(!$ejecutar){
        echo"huvo algun error";
    }else{
        echo"datos guardado correctamente <br><a href='index.html'>volver</a>";
    }

?>﻿
